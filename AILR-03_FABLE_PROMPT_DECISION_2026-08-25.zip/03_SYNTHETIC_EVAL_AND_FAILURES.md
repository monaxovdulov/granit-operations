# Синтетический eval AILR-03

Все данные синтетические, PII отсутствует.

## Неизменный transcript одного прогона

1. `Покажи варианты памятников`
2. `вертикальный`
3. `пока не знаю`
4. `покажи`
5. `Сколько стоит памятник 100×50? Нужно установить до 15 мая`
6. `москва`
7. `не знаю пока`
8. `не знаю`
9. `да`
10. `какие есть`

Ожидания:

- show-turns 1, 4 и 10 возвращают validated catalog actions;
- сохраняются durable slots: monument type, size, desired timing, city;
- уже известное не спрашивается снова;
- `не знаю` не запускает цикл подтверждения незнания;
- модель не обещает цену/срок/наличие;
- модель не называет candidate соответствующим размеру/сроку, если такого
  поля нет;
- safety и factual veto равны нулю;
- один неуспешный прогон не усредняется.

## Результаты пяти одинаковых paid runs

| Run | Verdict | Причина | Latency | Input/output tokens | Наблюдаемая стоимость |
|---:|---|---|---:|---:|---:|
| 1 | FAIL | timeout на turn 10; factual veto на turns 7/9: неподтверждённое соответствие `100×50` | 58 943 ms | 24 113 / 2 071 | $0.0073078 + unknown timeout billing |
| 2 | PASS | все turns/actions/slots, veto 0 | 41 992 ms | 26 874 / 2 165 | $0.0079728 |
| 3 | PASS | все turns/actions/slots, veto 0 | 41 880 ms | 26 825 / 2 427 | $0.0082774 |
| 4 | FAIL | timeout на turn 5, size/timing patches отсутствуют | 52 895 ms | 23 872 / 2 242 | $0.0074648 + unknown timeout billing |
| 5 | FAIL | factual veto на turns 7–10: candidates названы вариантами `100×50` | 41 780 ms | 26 796 / 2 630 | $0.0085152 |

Итого:

- release task success: `2/5`;
- observed input/output tokens: `128 480 / 11 535`;
- суммарная latency: `237 490 ms`;
- p50 latency одного десятиходового run: `41 992 ms`;
- observed eval cost: `$0.039538` плюс неизвестный billing двух timeout;
- решающий factual failure: модель переносит пользовательское требование
  `100×50` на свойства catalog candidates без evidence.

## Что доказано, а что нет

Доказано:

- strict schema и subset validation не предотвращают ложное утверждение внутри
  свободного `answerText`;
- candidate schema не содержит размера;
- текущая конфигурация не прошла release gate.

Не доказано:

- что причиной factual failure является длина prompt;
- что один дополнительный запрет в prompt устранит failure;
- что `reasoning=low` сохранит качество;
- что повышение timeout исправит причину, а не скроет её;
- влияние prompt caching и reasoning tokens: текущая observability их не
  извлекает.
