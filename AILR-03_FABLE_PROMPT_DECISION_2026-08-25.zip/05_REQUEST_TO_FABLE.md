# Задание Фейблу

Изучи только пять соседних файлов этого архива как evidence. Не предполагай
наличие другой архитектуры или дополнительных catalog fields.

Нужно принять решение для следующей версии AILR-03, а не реализовать её.

## Вопрос

Какой минимальный prompt и какой минимальный app-owned grounding mechanism
нужны для GPT-5.6 Luna, чтобы:

- по «покажи» стабильно выдавать 1–3 validated recommendation IDs;
- сохранять естественный короткий русский ответ;
- никогда не представлять пользовательские size/timing requirements как
  подтверждённые свойства catalog candidates, если полей нет;
- не раздувать prompt и не дублировать strict JSON Schema;
- сохранить один model call, текущую модель, Responses API и server-owned
  ID/URL validation?

## Сравни три варианта

1. Только lean prompt v4.
2. Lean prompt плюс typed grounding/output claim contract.
3. Lean prompt плюс server-composed catalog text при непустых
   `recommendationIds`.

Для каждого варианта оцени:

- закрывает ли он observed factual failure;
- остающийся failure mode;
- сложность и blast radius;
- влияние на естественность ответа;
- необходимые deterministic tests и paid eval;
- совместимость с актуальными рекомендациями OpenAI для GPT-5.6.

## Требуемый результат

Верни:

1. один выбранный вариант и краткое обоснование;
2. точный предлагаемый текст prompt v4 целиком, без placeholder;
3. какие строки prompt v3 удалить, объединить или сохранить;
4. минимальное изменение output/server contract, если оно нужно;
5. eval gate и отдельную latency-абляцию `medium` против `low`;
6. точный blocker, если данных недостаточно.

Не предлагай одновременно менять model, reasoning, timeout, state retention и
prompt. Не выдавай повышение timeout за исправление factual grounding.
