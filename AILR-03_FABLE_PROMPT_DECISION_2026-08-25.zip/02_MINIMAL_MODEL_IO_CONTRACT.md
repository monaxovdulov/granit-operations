# Минимальный model I/O contract

## API request

- endpoint: OpenAI Responses API;
- model: `gpt-5.6-luna`;
- `store:false`;
- `reasoning.effort: medium`;
- `text.verbosity: low`;
- strict `text.format.type: json_schema`;
- один запрос модели на пользовательский turn;
- eval timeout был зафиксирован на 12 000 ms;
- output budget: 4 000 tokens.

## Динамический input

```json
{
  "decisionProfile": "live_v2",
  "turn": {
    "messages": "до 8 последних visitor/assistant сообщений",
    "lastAiQuestion": "string|null",
    "knownSlots": {
      "monumentType": "string?",
      "material": "string?",
      "size": "string?",
      "city": "string?",
      "desiredTiming": "string?"
    },
    "gate": "app-owned reply permission"
  },
  "catalogCandidates": [
    {
      "id": "ent_<16 hex>",
      "title": "string",
      "categorySlug": "string",
      "groupSlug": "string",
      "searchTerms": ["string"],
      "material": ["string"]
    }
  ],
  "tone": "versioned tone asset",
  "facts": "versioned approved facts"
}
```

Критично: у `catalogCandidates` нет `size`, `availability`, `price`,
`installationDate` или признака соответствия пользовательским требованиям.

## Strict model output

```json
{
  "version": "granit_model_turn.v1",
  "message": {
    "answerText": "1..900 chars",
    "question": {
      "text": "1..320 chars",
      "target": "known slot enum"
    }
  },
  "statePatches": [
    {
      "operation": "set_slot|upsert_requirement",
      "value": "string",
      "confidence": 0.0,
      "evidence": { "quote": "exact current-message quote" }
    }
  ],
  "recommendationIds": ["up to 8 candidate IDs"],
  "handoffIntent": null
}
```

`question` и `handoffIntent` nullable; все objects strict.

## App-owned enforcement после модели

- state patch принимается только при точной evidence quote из текущего
  сообщения;
- recommendation IDs должны быть уникальным subset переданных candidates;
- публично сохраняются максимум первые три validated ID;
- title, href и кнопка строятся сервером по pinned catalog snapshot;
- неизвестные/повторные ID отбрасываются fail closed;
- свободный `message.answerText` сейчас не проходит semantic factual grounding
  относительно полей candidate. Это и есть незакрытая поверхность риска.
