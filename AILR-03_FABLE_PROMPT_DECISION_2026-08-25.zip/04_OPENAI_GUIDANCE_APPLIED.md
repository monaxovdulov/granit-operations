# Актуальные рекомендации OpenAI для GPT-5.6

Проверено по официальной документации OpenAI 2026-08-25.

## Рекомендации

1. GPT-5.6 предпочитает lean outcome-first prompts: цель, relevant context,
   constraints, success criteria и output. Инструкцию следует формулировать
   один раз. Абсолютные `always/never` нужны только для настоящих инвариантов.
2. Начинать следует с одного узкого агента. Multi-agent добавляется только при
   отдельном ownership/tool/approval surface.
3. Для reasoning/tool/multi-turn workloads использовать Responses API.
4. `medium` — balanced baseline; для latency-sensitive workloads сравнивать с
   `low` на representative evals, не предполагать результат.
5. Structured Outputs обеспечивает schema adherence, но проверяемые input,
   output и tool ограничения должны иметь guardrails.
6. Сначала разбирать traces; затем переносить известные failures в repeatable
   datasets/evals.
7. Для stateless `store:false` continuation OpenAI рекомендует replay полного
   `response.output`, включая encrypted reasoning items. Это потенциальная
   отдельная оптимизация, но здесь она затрагивает state/privacy contract и не
   должна незаметно входить в prompt repair.
8. GPT-5.6 поддерживает automatic/explicit prompt caching. Stable content
   должен предшествовать dynamic content; эффект подтверждается cached-token
   observability.

## Применение к AILR-03

Уже соответствует рекомендациям:

- Responses API;
- strict Structured Outputs;
- один сфокусированный agent/model call;
- `gpt-5.6-luna`, reasoning medium, verbosity low;
- server-owned validation ID и URL.

Не следует делать сейчас:

- наращивать список повторяющихся `НЕ/НИКОГДА`;
- менять модель одновременно с prompt;
- переходить на Agents SDK, multi-agent или Programmatic Tool Calling;
- считать schema validation проверкой фактического смысла `answerText`;
- менять reasoning и timeout без отдельной абляции.

Направление для решения:

- prompt должен содержать один короткий grounding-инвариант;
- фактическое соответствие позиции требованиям должно быть типизировано и
  проверяемо либо catalog-часть текста должна собираться сервером;
- полные JSON-примеры и инструкция «верни JSON» являются кандидатами на
  удаление/абляцию, потому что строгая schema уже передана API;
- любое изменение сравнивается на том же transcript и отдельном adversarial
  кейсе неподтверждённых свойств.

## Официальные источники

- GPT-5.6 model guidance:
  https://developers.openai.com/api/docs/guides/latest-model
- GPT-5.6 Luna model:
  https://developers.openai.com/api/docs/models/gpt-5.6-luna
- Agent definitions:
  https://developers.openai.com/api/docs/guides/agents/define-agents
- Guardrails and human review:
  https://developers.openai.com/api/docs/guides/agents/guardrails-approvals
- Evaluate agent workflows:
  https://developers.openai.com/api/docs/guides/agent-evals
- Reasoning best practices:
  https://developers.openai.com/api/docs/guides/reasoning-best-practices
- Structured Outputs:
  https://developers.openai.com/api/docs/guides/structured-outputs
- Conversation state:
  https://developers.openai.com/api/docs/guides/conversation-state
