# AILR-03: решение по prompt и grounding

Дата среза: 2026-08-25.

Это минимальный read-only контекст для архитектурного решения. В архиве нет
секретов, PII, production-данных, логов, полного каталога, build output и полного
репозитория. Transcript и идентификаторы синтетические.

## Что нужно решить

Русскоязычный виджет гранитной мастерской должен по просьбе «покажи» выбрать
до трёх опубликованных позиций из короткого server-provided candidate set.
Модель возвращает строгий JSON; сервер проверяет ID и сам строит URL/кнопки.

Пять одинаковых платных eval-прогонов текущей конфигурации дали только 2/5
полных успехов:

- два provider timeout;
- в двух других неуспешных прогонах модель назвала показанные позиции
  соответствующими размеру `100×50`, хотя у candidate нет поля размера.

Нужно определить минимальный следующий дизайн:

1. какой prompt нужен GPT-5.6 Luna;
2. что должно остаться prompt-инвариантом;
3. что должно быть обеспечено output contract / server validation / canonical
   server composition, а не инструкцией модели;
4. как проверить изменение без одновременной смены нескольких механизмов.

## Жёсткие границы решения

- модель остаётся `gpt-5.6-luna`;
- baseline reasoning остаётся `medium`; сравнение с `low` возможно только как
  отдельная абляция;
- Responses API, `store:false`, strict Structured Outputs и один model call на
  turn сохраняются;
- модель не создаёт URL и не может рекомендовать ID вне candidate set;
- app-owned durable slots остаются источником истины;
- не предлагать Agents SDK migration, multi-agent, новые tools, fine-tuning или
  RAG без доказанного blocker;
- сохранить естественный краткий русский ответ;
- любые свойства позиции должны быть подтверждены полями candidate;
- параметры пользователя, например размер и срок, являются требованиями, а не
  автоматически подтверждёнными свойствами позиции.

## Версии

- repo SHA: `7bbf68eff23afa88ca756c2bc1ac280c8463fb7e`;
- worktree содержит незакоммиченный AILR-03 RC;
- prompt version: `granit_model_turn_prompt.v3`;
- eval-recorded prompt fingerprint:
  `8a7d5d18435cfeafb9bb88c6884abf3c8d575066817ceee028419a26a3b1fe27`;
- SHA-256 файла с текущим prompt:
  `774581638f7b0cde96d195b6639eacec0ef400f09a15067030e967342ab488c2`;
- output contract: `granit_model_turn.v1`;
- model profile: `granit_model_turn_openai_luna.v1`;
- catalog version: `landing-catalog.e76ee8be770a`;
- catalog hash:
  `94038ef1954ce38691d3bc85b3f658c1d9ad1bfc7a428037d66b26f07d87d22b`.

Начните с `05_REQUEST_TO_FABLE.md`.
